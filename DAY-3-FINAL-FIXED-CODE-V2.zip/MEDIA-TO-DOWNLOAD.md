# MEDIA TO DOWNLOAD FOR DAY-3

Put the files in these exact paths/names.

## Required images

1. `assets/images/hero.jpg`
   - Real Artista Perfetto Ancoats exterior/storefront photo, ideally with people or street context.
   - Landscape, ideally 1600px+ wide.

2. `assets/images/shop.jpg`
   - A DIFFERENT real storefront or interior/counter photo.
   - Landscape, ideally 1400px+ wide.

3. `assets/images/coffee-1.jpg`
   - Real Artista Perfetto drink + bake photo. If you can verify The Dirty, use that.
   - Portrait or square works.

4. `assets/images/coffee-2.jpg`
   - A DIFFERENT real drink/brewing/barista close-up.
   - Do not reuse coffee-1.

5. `assets/images/official-storefront.jpg`
   - Real official location/storefront image for the Visit section.
   - Landscape or square.

6. `assets/images/video-poster.jpg`
   - Still frame/thumbnail from the SAME real video used below.
   - 16:9 if desktop video; vertical 9:16 is also acceptable because mobile crops it.

## Recommended video

`assets/video/story.mp4`

Best choice: one real Artista Perfetto clip, 8–30 seconds, showing one or more of:
- barista preparing The Dirty or Iced Blackcinno
- espresso extraction / pouring / milk layering at the actual shop
- owner/team speaking or working behind the counter
- a short walkthrough of the Ancoats shop

Technical target:
- MP4 (H.264)
- 1080p is enough
- ideally under 15–20 MB for GitHub Pages
- no copyrighted background music unless you have permission

Use only media you have permission to rehost publicly. If you do not have permission for the Manchester's Finest/Instagram video, leave `story.mp4` absent; the site will show the external original-coverage buttons instead.
